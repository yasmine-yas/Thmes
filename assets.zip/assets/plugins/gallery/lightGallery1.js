$(function(e) {
	lightGallery(document.getElementById('lightgallery'));
});

